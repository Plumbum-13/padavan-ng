Copy "mdig" folder here !
